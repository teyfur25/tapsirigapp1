UniversityDB - SQL tapşırığı

Fayllar:
- UniversityDB_GetStudentResult.sql: Tapşırığın tam SQL kodu.

İstifadə:
1. SQL Server Management Studio (SSMS) proqramını açın.
2. .sql faylını açın.
3. Kodu ilk dəfə yuxarıdan aşağıya qədər ardıcıllıqla icra edin (Execute).

Qeyd:
Database artıq mövcuddursa, CREATE DATABASE sətrində xəta yarana bilər.
