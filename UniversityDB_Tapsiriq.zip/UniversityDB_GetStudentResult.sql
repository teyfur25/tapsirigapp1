-- 1. Database yaratmaq
CREATE DATABASE UniversityDB;
GO

-- 2. Database-i secmek
USE UniversityDB;
GO

-- 3. Students cedvelini yaratmaq
CREATE TABLE Students
(
    Id INT PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL,
    Score INT NOT NULL
);
GO

-- 4. Cedvele melumatlari elave etmek
INSERT INTO Students (Id, Name, Score)
VALUES
(1, N'Ali', 85),
(2, N'Leyla', 72),
(3, N'Murad', 48),
(4, N'Aysel', 91),
(5, N'Kamran', 63);
GO

-- 5. Stored Procedure yaratmaq
CREATE PROCEDURE GetStudentResult
    @StudentId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM Students
        WHERE Id = @StudentId
    )
    BEGIN
        SELECT
            Name,
            Score,
            CASE
                WHEN Score BETWEEN 90 AND 100 THEN 'A'
                WHEN Score BETWEEN 80 AND 89 THEN 'B'
                WHEN Score BETWEEN 70 AND 79 THEN 'C'
                WHEN Score BETWEEN 60 AND 69 THEN 'D'
                WHEN Score BETWEEN 0 AND 59 THEN 'F'
            END AS Grade
        FROM Students
        WHERE Id = @StudentId;
    END
    ELSE
    BEGIN
        SELECT N'Student not found' AS Message;
    END
END;
GO

-- 6. Procedure-u test etmek
EXEC GetStudentResult @StudentId = 1;
GO

EXEC GetStudentResult @StudentId = 3;
GO

-- 7. Olmayan telebeni yoxlamaq
EXEC GetStudentResult @StudentId = 10;
GO
